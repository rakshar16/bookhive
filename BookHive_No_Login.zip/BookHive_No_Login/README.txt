BOOKHIVE - ONLINE BOOKSTORE

Files:
- index.html : Main website page
- style.css  : Website design and responsive layout
- script.js  : Book search, category filter, sorting, cart and contact demo

HOW TO RUN:
1. Extract the ZIP file.
2. Open the BookHive_No_Login folder.
3. Double-click index.html to open it in your browser.

NOTE:
- This version does not contain a login page or login option.
- Checkout and contact form are front-end demonstrations. They do not process real payments or send messages to a server.
- Google Fonts require an internet connection; the site still works with fallback fonts.
