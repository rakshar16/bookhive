const books = [
    { id: 1, title: "The Alchemist", author: "Paulo Coelho", category: "Fiction", price: 299, cover: 1 },
    { id: 2, title: "The Silent Patient", author: "Alex Michaelides", category: "Fiction", price: 349, cover: 2 },
    { id: 3, title: "Atomic Habits", author: "James Clear", category: "Self-Help", price: 450, cover: 3 },
    { id: 4, title: "The Power of Now", author: "Eckhart Tolle", category: "Self-Help", price: 399, cover: 4 },
    { id: 5, title: "Clean Code", author: "Robert C. Martin", category: "Technology", price: 599, cover: 5 },
    { id: 6, title: "Python Crash Course", author: "Eric Matthes", category: "Technology", price: 550, cover: 6 },
    { id: 7, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", category: "Business", price: 320, cover: 7 },
    { id: 8, title: "The Psychology of Money", author: "Morgan Housel", category: "Business", price: 375, cover: 8 }
];

let cart = [];

const bookList = document.getElementById("book-list");
const searchInput = document.getElementById("search");
const categorySelect = document.getElementById("category");
const sortSelect = document.getElementById("sort");

function displayBooks() {
    let filteredBooks = [...books];
    const searchText = searchInput.value.toLowerCase().trim();
    const selectedCategory = categorySelect.value;

    filteredBooks = filteredBooks.filter(book =>
        (book.title.toLowerCase().includes(searchText) ||
         book.author.toLowerCase().includes(searchText)) &&
        (selectedCategory === "All" || book.category === selectedCategory)
    );

    if (sortSelect.value === "low") filteredBooks.sort((a, b) => a.price - b.price);
    if (sortSelect.value === "high") filteredBooks.sort((a, b) => b.price - a.price);

    bookList.innerHTML = filteredBooks.map(book => `
        <article class="book-card">
            <div class="book-cover cover-${book.cover}">
                <span>${book.title}</span>
            </div>
            <div class="book-info">
                <span class="category-tag">${book.category}</span>
                <h3>${book.title}</h3>
                <p class="author">by ${book.author}</p>
                <div class="book-bottom">
                    <span class="book-price">₹${book.price}</span>
                    <button class="add-button" onclick="addToCart(${book.id})">Add to Cart</button>
                </div>
            </div>
        </article>
    `).join("");

    document.getElementById("no-books").hidden = filteredBooks.length !== 0;
}

function addToCart(bookId) {
    const book = books.find(item => item.id === bookId);
    const existingItem = cart.find(item => item.id === bookId);
    if (existingItem) existingItem.quantity += 1;
    else cart.push({ ...book, quantity: 1 });
    updateCart();
}

function removeFromCart(bookId) {
    cart = cart.filter(item => item.id !== bookId);
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById("cart-items");
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

    document.getElementById("cart-count").textContent = count;
    document.getElementById("cart-total").textContent = total.toLocaleString("en-IN");

    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">Your cart is empty. Add a book to get started!</p>';
    } else {
        cartItems.innerHTML = cart.map(item => `
            <div class="cart-row">
                <div>
                    <h4>${item.title}</h4>
                    <small>₹${item.price} × ${item.quantity}</small>
                </div>
                <strong>₹${item.price * item.quantity}</strong>
                <button class="remove-button" onclick="removeFromCart(${item.id})">Remove</button>
            </div>
        `).join("");
    }
}

searchInput.addEventListener("input", displayBooks);
categorySelect.addEventListener("change", displayBooks);
sortSelect.addEventListener("change", displayBooks);

document.getElementById("checkout-button").addEventListener("click", () => {
    const message = document.getElementById("checkout-message");
    if (cart.length === 0) {
        message.textContent = "Your cart is empty. Please add a book first.";
    } else {
        message.textContent = "Thank you! Your demo order has been placed successfully.";
        cart = [];
        updateCart();
    }
});

document.getElementById("contact-form").addEventListener("submit", event => {
    event.preventDefault();
    document.getElementById("contact-response").textContent =
        "Thank you for contacting BookHive! Your message has been received.";
    event.target.reset();
});

document.getElementById("menu-toggle").addEventListener("click", () => {
    document.getElementById("nav-links").classList.toggle("open");
});

document.querySelectorAll(".nav-links a").forEach(link => {
    link.addEventListener("click", () => {
        document.getElementById("nav-links").classList.remove("open");
    });
});

displayBooks();
updateCart();
